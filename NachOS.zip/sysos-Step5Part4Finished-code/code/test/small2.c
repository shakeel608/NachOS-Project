#include "syscall.h"


int main()
{
	PutChar('0');
	PutChar('1');
	PutChar('2');
	PutChar('3');
	PutChar('4');
	PutChar('5');
}