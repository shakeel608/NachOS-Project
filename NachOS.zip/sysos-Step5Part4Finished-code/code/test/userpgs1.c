#include "syscall.h"

int main()
{
	PutString("Child\n");
}