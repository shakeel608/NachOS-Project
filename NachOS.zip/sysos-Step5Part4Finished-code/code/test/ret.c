#include "syscall.h"


int main()
{
	//Halt();

 	return 15;

}



