#include "syscall.h"


int main()
{
	PutChar('A');
	PutChar('B');
	PutChar('C');
	PutChar('D');
	PutChar('E');
	PutChar('F');
}