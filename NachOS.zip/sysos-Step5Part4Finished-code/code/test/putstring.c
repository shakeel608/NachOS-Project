#include "syscall.h"

int
main() {

    PutString("Bismillah \n");

    //PutString("In the name of Allah the most beneficient and most merciful\n");
    //PutString("In the name of Allah the most beneficient and most merciful\n");
    PutString("ibn Bashir reported: The Messenger of Allah, peace and blessings be upon him, saidThe parable of the believers in their affection, mercy, and compassion for each other is that of a body. When any limb aches, the whole body reacts with sleeplessness and fever\n");
   
    return 0;
}
